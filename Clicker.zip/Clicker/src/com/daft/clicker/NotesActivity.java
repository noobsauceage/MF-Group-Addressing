package com.daft.clicker;

import android.app.Activity;

public class NotesActivity extends Activity {
// get pdf/ppt notes somehow
}
