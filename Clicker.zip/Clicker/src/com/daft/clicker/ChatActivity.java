package com.daft.clicker;

import android.app.Activity;

public class ChatActivity extends Activity {
// group chat
}
