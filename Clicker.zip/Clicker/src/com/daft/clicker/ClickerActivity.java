package com.daft.clicker;

import android.app.Activity;

public class ClickerActivity extends Activity {
	// communicate with php scripts on server to handle question/answer
	// mechanics
}
